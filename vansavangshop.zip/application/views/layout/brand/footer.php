<hr />
<div class="text-center">
  
  <!--
Support: <a href="https://www.facebook.com/cus2merpage" target="_blank">
  C2M Facebook Page
</a> 

-->
</div>

<?php

$modal_enddate =  '


<div class="modal fade" id="modal-enddate">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header text-left">
				
				<h4 class="modal-title">หมดอายุการใช้งาน</h4>
			</div>
			<div class="modal-body">

<center>
การใช้งานของคุณหมดอายุแล้ว</font>
			<br />
			กรุณาต่ออายุ เพื่อใช้งาน
			<br />
			 <a class="btn btn-success" href="'.$base_url.'/renew"> ต่ออายุการใช้งาน</a>
			<hr />

			 <br />
			<a href="'.$base_url.'/logout"> ออกจากระบบ</a>
			</center>	

		</div>

			</div>
			
		</div>



	</div></div>



<script>
$("#modal-enddate").modal({backdrop: "static", keyboard: false});
</script>

';

?>





</body>
</html>



