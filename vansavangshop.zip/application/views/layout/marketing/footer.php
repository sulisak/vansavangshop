﻿<div class="col-md-12 text-center">
Support: <a href="https://www.facebook.com/cus2merpage" target="_blank">
  C2M Fackbook Page
</a> 
</div>




<hr />
</body>
</html>