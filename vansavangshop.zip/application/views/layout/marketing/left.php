
<style type="text/css">
	.nav-pills > li.active > a, .nav-pills > li.active > a:focus, .nav-pills > li.active > a:hover {
    color: #fff;
    background-color: #000;
}
a{
	color: #000000;
}
</style>
<div class="col-md-2 col-sm-3">
	

	<div class="panel panel-default">
		<div class="panel-body">
		
	
		<ul class="nav nav-pills nav-sidebar">	

<li style="width: 100%;" <?php if($tab === 'email'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/marketing/email"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> 
<?=$lang_emailmarketting?>
</a></li>



</ul>




</div>

</div>










</div>