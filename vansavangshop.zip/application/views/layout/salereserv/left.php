
<style type="text/css">
	.nav-pills > li.active > a, .nav-pills > li.active > a:focus, .nav-pills > li.active > a:hover {
    color: #fff;
    background-color: #000;
}
a{
	color: #000000;
}
</style>
<div class="col-md-2 col-sm-3">


	<div class="panel panel-default">
		<div class="panel-body">


		<ul class="nav nav-pills nav-sidebar">

<li style="width: 100%;" <?php if($tab === 'salebill'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/sale/salebill"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>
บิลขาย
<br />
เครดิต/ค้างชำระ </a></li>




<!-- <li style="width: 100%;" <?php if($tab === 'salereserv'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/sale/salereserv"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span>
รายการจอง
 </a></li> -->



</ul>




</div>

</div>











</div>
