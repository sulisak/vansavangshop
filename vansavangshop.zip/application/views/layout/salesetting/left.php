﻿
<style type="text/css">
	.nav-pills > li.active > a, .nav-pills > li.active > a:focus, .nav-pills > li.active > a:hover {
    color: #fff;
    background-color: #f0ad4e;
}
a{
	color: #000000;
}
</style>
<div class="col-md-2 col-sm-3">


	<div class="panel panel-default">
		<div class="panel-body">


		<ul class="nav nav-pills nav-sidebar">


<li style="width: 100%;" <?php if($tab === 'pay_type'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/pay_type"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	 <?php echo $lang_lost_1;?></a></li>
	
	<li style="width: 100%;" <?php if($tab === 'name_of_price'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/name_of_price"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	5 ລາຄາ </a></li>

	
<li style="width: 100%;" <?php if($tab === 'exchangerate'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/exchangerate"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	 <?php echo $lang_lost_2;?></a></li>

<li style="width: 100%;" <?php if($tab === 'discount'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/discount"><span class="glyphicon glyphicon-flash" aria-hidden="true"></span>
	<?=$lang_settingdiscount?> </a></li>

<li style="width: 100%;" <?php if($tab === 'pricebycus'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/pricebycus"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	<?=$lang_settingpricecus?> </a></li>


<li style="width: 100%;" <?php if($tab === 'pricebycusgroup'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/pricebycusgroup"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	<?=$lang_settingpricecusgroup?>  </a></li>

<li style="width: 100%;" <?php if($tab === 'pricebystep'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/pricebystep"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	Step Price By QTY<br /> ລາຄາສິນຄ້າຕາມ ຈຳນວນທີ່ຊື້  </a></li>
	
<li style="width: 100%;" <?php if($tab === 'numtoprice'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/numtoprice"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	Step Price Per QTY<br /> ທຸກໆ X ຊີ້ນ ຈະລາຄາ xxx   </a></li>

<li style="width: 100%;" <?php if($tab === 'product_point'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/product_point"><span class="glyphicon glyphicon-flash" aria-hidden="true">
	</span> <?php echo $lang_lost_4_1;?> </a></li>


<li style="width: 100%;" <?php if($tab === 'round_setting'){ echo 'class="active"';} ?> ><a href="<?php echo $base_url; ?>/salesetting/round_setting"><span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	<?php echo $lang_lost_5;?>  </a></li>
	
	

<li style="width: 100%;" <?php if($tab === 'setting_etc'){ echo 'class="active"';} ?> >
	<a href="<?php echo $base_url; ?>/salesetting/setting_etc">
		<span class="glyphicon glyphicon-flash" aria-hidden="true">
		</span>  <?php echo $lang_lost_6;?></a></li>


<li style="width: 100%;" <?php if($tab === 'linenotify'){ echo 'class="active"';} ?> >
		<a href="<?php echo $base_url; ?>/salesetting/linenotify">
		<span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
	ແຈ້ງເຕື່ອນຜ່ານທາງ LINE Notify  </a></li>

</ul>




</div>

</div>










</div>
