﻿<div class="col-md-12 text-center">
	Language <a href="<?php echo $base_url;?>/?lang=th">ภาษาไทย</a> 
| <a href="<?php echo $base_url;?>/?lang=lao">ພາສາລາວ</a>
<br />
Support: <a href="https://www.facebook.com/cus2merpage" target="_blank">
  C2M Facebook Page
</a> 
</div>




<hr />


<script src="<?php echo $base_url; ?>/js/excel-export.js"></script>


</body>
</html>