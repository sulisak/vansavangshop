

<div class="col-md-12 col-sm-12 col-xs-12 text-center" style="color: #fff;">


<!-- 	Language <a style="color: #fff;" href="<?php echo $base_url;?>/?lang=th">ภาษาไทย</a> 
	| <a style="color: #fff;" href="<?php echo $base_url;?>/?lang=lao">ພາສາລາວ</a>
<br /> -->

<center>
<span style="color: #fff;">

<br />




</span>
<br /> 
<br />
</center>

</div>






